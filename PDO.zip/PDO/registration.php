<?php
/**
 * Created by PhpStorm.
 * User: XY
 * Date: 2017/8/26
 * Time: 15:42index
 */
include_once __DIR__ . '/index.php';
//注册并将用户名和密码传入数据库
$name = $_POST['username'];
$password = ($_POST['password']);
$sql = "insert into regis(username,password) values ('$name','$password')";
$exec = $db->query($sql);
if($exec){
    echo "alert'成功';location.href = 'user.html'";//user.html 为注册界面
}else{
    echo "alert'失败';location.href = 'user.html'";
}
