<?php
/**
 * Created by PhpStorm.
 * User: XY
 * Date: 2017/8/26
 * Time: 15:42
 */
include_once __DIR__ . '/index.php';
//在数据库中对用户输入的用户名和密码进行查询验证
$name = $_POST['name'];
$password = $_POST['password'];
$sql = "select * from regis where username='$name' and password='$password'";
$land = $db->query($sql);
$info = $land->fetch(PDO::FETCH_ASSOC);
if($info){
    echo "登录成功";
}else{
    echo "登录失败";
}