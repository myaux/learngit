<?php
/**
 * Created by PhpStorm.
 * User: XY
 * Date: 2017/8/26
 * Time: 15:41
 */
//链接数据库
try{
    $db = new PDO('mysql:host = localhost:dbname = reg','root','zfy5201314');
}catch (PDOException$error) {
    echo '链接数据库失败'.$error->getMessage();
    exit();
}